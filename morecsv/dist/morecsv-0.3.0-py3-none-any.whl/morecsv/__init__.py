# morecsv/__init__.py
from morecsv import CSVProcessor

__all__ = ['CSVProcessor']